/**
 * @file     temperature.h
 * @brief    adc based temperature reading task source
 * @author   OUASSARNI Fahd
 * @date
 */

#include "temperature.h"
