/**
 * @file     console.c
 * @brief    uart based console task source
 * @author   OUASSARNI Fahd
 * @date
 */

#include "console.h"
