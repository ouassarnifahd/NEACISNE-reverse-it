/**
* @file     utask.c
* @brief    user tasks and kernel config source
* @author   OUASSARNI Fahd
* @date
*/

/* INCLUDES DEPENDENCIES ***************/
#include <utask.h>
/* include all headers dependencies into utask.h file */

/**
* @fn void kernelConfig(void)
* @brief kernel configuration
*/
void kernelConfig(void){

   //xTaskCreate(readcommand, "wait for request", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + 1, NULL);

   //xTaskCreate(getADCvalue, "read temperature", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + 1, NULL);

   //xTaskCreate(sendreply, "send reply", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + 1, NULL);

 }

/**
* @fn void vApplicationIdleHook( void )
* @brief function called by idle task
*/
void vApplicationIdleHook(void) {
    // updateLED();
}
