/**
 * @file     led.c
 * @brief    led handling task source
 * @author   OUASSARNI Fahd
 * @date
 */

#include "led.h"
