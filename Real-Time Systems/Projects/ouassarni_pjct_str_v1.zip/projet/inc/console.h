/**
 * @file     console.h
 * @brief    header for uart based console task
 * @author   OUASSARNI Fahd
 * @date
 */

#ifndef __HEADER_CONSOLE_TASK__
#define __HEADER_CONSOLE_TASK__

#include <uart.h>



#endif /* end of include guard: __HEADER_CONSOLE_TASK__ */
