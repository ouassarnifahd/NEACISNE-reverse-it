/**
 * @file     led.h
 * @brief    header for led handling task
 * @author   OUASSARNI Fahd
 * @date
 */

#ifndef __HEADER_LED_TASK__
#define __HEADER_LED_TASK__

// #include <.h> // led handling dependencies
#include "temperature.h"


#endif /* end of include guard: __HEADER_LED_TASK__ */
