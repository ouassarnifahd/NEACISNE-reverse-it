/**
 * @file     temperature.h
 * @brief    header for adc based temperature reading task
 * @author   OUASSARNI Fahd
 * @date
 */

#ifndef __HEADER_TEMPERATURE_TASK__
#define __HEADER_TEMPERATURE_TASK__

#include <adc.h>



#endif /* end of include guard: __HEADER_TEMPERATURE_TASK__ */
