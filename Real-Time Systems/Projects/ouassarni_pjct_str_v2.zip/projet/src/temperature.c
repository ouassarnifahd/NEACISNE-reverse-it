/**
 * @file     temperature.h
 * @brief    adc based temperature reading task source
 * @author   OUASSARNI Fahd
 * @date
 */
#include "temperature.h"

void xQueueTempStreamConfig(void) {
    
    vSemaphoreCreateBinary( xSemaphoreTempRead );
    if( xSemaphoreTempRead == NULL ) {
        /* There was insufficient FreeRTOS heap available for the semaphore to
        be created successfully. */
        while(1);
    }

    xQueueTempStream = xQueueCreate( 1, sizeof( float ) );
    if( xQueueTempStream == NULL ) {
        /* Queue was not created and must not be used. */
        while(1);
    }

}

void xQueueTempBufferConfig(void) {

    xQueueTempBuffer = xQueueCreate( MAX_SIZE_BUFFER, sizeof( float ) );
    if( xQueueTempBuffer == NULL ) {
        /* Queue was not created and must not be used. */
        while(1);
    }

}

float adc2temp(int adcValue) {
    return ((adcValue * 270) / (float)1023) - 40.0;
}
