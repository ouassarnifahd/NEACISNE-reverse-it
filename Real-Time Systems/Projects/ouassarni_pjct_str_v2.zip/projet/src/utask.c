/**
* @file     utask.c
* @brief    user tasks and kernel config source
* @author   OUASSARNI Fahd
* @date
*/

/* INCLUDES DEPENDENCIES ***************/
#include <utask.h>
/* include all headers dependencies into utask.h file */

/**
* @fn void kernelConfig(void)
* @brief kernel configuration
*/
void kernelConfig(void){

   xQueueTempStreamConfig();
   xQueueTempBufferConfig();

   xTaskCreate(consoleTask, "uart console management", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + 2, NULL);
   xTaskCreate(sensorTask, "temperature sensor data flow", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + 2, NULL);
   xTaskCreate(ledUpdateTask, "led management", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY, NULL);

 }

/**
* @fn void consoleTask( void *pvParameters )
* @brief console handling task
*/
void consoleTask(void *pvParameters) {

    int user_command_id = -1;
    const portTickType xDelay = 20;

    consoleInit();

    for(;;) {
        uartprintf("freertos:~# ");
        user_command_id = consoleReadCommand();
        consoleReply(user_command_id);
        vTaskDelay(xDelay);
    }

}

/**
* @fn void sensorTask( void *pvParameters )
* @brief temperature acquisition task
*/
void sensorTask(void *pvParameters) {

    float tempStream, tempTrash;

    portTickType xLastWakeTime;
    const portTickType xFrequency = 20;

    // Initialize the xLastWakeTime variable with the current time.
    xLastWakeTime = xTaskGetTickCount();

    for(;;)
    {
        // Wait for the next cycle.
        vTaskDelayUntil( &xLastWakeTime, xFrequency );

        // Perform action here.
        tempStream = adc2temp(adcRead());

        xQueueSend(xQueueTempStream, &tempStream, MAX_SEND_DELAY);
        if ( xQueueSend(xQueueTempBuffer, &tempStream, MAX_SEND_DELAY) != pdTRUE ) {
            xQueueReceive(xQueueTempBuffer, &tempTrash, MAX_SEND_DELAY);
        }

    }

}

/**
* @fn void ledUpdateTask( void *pvParameters )
* @brief led hangling task
*/
void ledUpdateTask(void *pvParameters) {

    for(;;) {
        updateLED();
        vTaskDelay(LED_BLINK_PERIOD);
    }

}
