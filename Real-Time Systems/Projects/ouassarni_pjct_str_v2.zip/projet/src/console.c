/**
 * @file     console.c
 * @brief    uart based console task source
 * @author   OUASSARNI Fahd
 * @date
 */

#include "console.h"
#include <FreeRTOS.h>
#include <task.h>
#include <string.h>

const char *builtincommands[BUILTIN_COMMANDS_NUMBER] = {
    "read", "dump", "stream", "reset", "baudrate", "help"
};

const char helpMSG[] =
    "read      return last converted value\r\n"
    "dump      return hundred last converted values\r\n"
    "stream    return last converted value and update display\r\n"
    "          press ENTER to quit stream mode\r\n"
    "reset     software processor reset\r\n"
    "baudrate  update serial communication baudrate of processor\r\n"
    "help      return supported commands\r\n"
;


static void serverRead(void) {
    float tempValue;

    if( xSemaphoreTempRead != NULL )
    {
        /* See if we can obtain the semaphore.  If the semaphore is not
        available wait 10 ticks to see if it becomes free. */
        if( xSemaphoreTake( xSemaphoreTempRead, CONSOLE_TIMEOUT ) == pdTRUE )
        {
            /* We were able to obtain the semaphore and can now access the
            shared resource. */

            xQueueReceive(xQueueTempStream, &tempValue, CONSOLE_TIMEOUT);

            /* We have finished accessing the shared resource.  Release the
            semaphore. */
            xSemaphoreGive( xSemaphoreTempRead );
        }
        else
        {
            /* We could not obtain the semaphore and can therefore not access
            the shared resource safely. */
            xQueuePeek(xQueueTempStream, &tempValue, CONSOLE_TIMEOUT);
        }
    }

    uartprintf("%2.1f°C\r\n", tempValue);
    return ;
}

static void serverDump(void) {
    float tempValue;
    int i, bufferEnd;

    for (i = 1; i <= MAX_SIZE_BUFFER; i++) {
        xQueueReceive(xQueueTempBuffer, &tempValue, CONSOLE_TIMEOUT);
        uartprintf("%2.1f°C   %d", tempValue, i);
        if (i == 1) uartprintf(" (Current)");
        uartprintf("\r\n");
    }

    return ;
}

static void serverStream(void) {
    float tempValue;
    const char ENTER = '\r';
    while (uartGetC() != ENTER) {
        if( xSemaphoreTempRead != NULL )
        {
            /* See if we can obtain the semaphore.  If the semaphore is not
            available wait 10 ticks to see if it becomes free. */
            if( xSemaphoreTake( xSemaphoreTempRead, CONSOLE_TIMEOUT ) == pdTRUE )
            {
                /* We were able to obtain the semaphore and can now access the
                shared resource. */

                xQueueReceive(xQueueTempStream, &tempValue, CONSOLE_TIMEOUT);

                /* We have finished accessing the shared resource.  Release the
                semaphore. */
                xSemaphoreGive( xSemaphoreTempRead );
            }
            else
            {
                /* We could not obtain the semaphore and can therefore not access
                the shared resource safely. */
                xQueuePeek(xQueueTempStream, &tempValue, CONSOLE_TIMEOUT);
            }
        }
        uartprintf("freertos:~# %2.1f°C   \r", tempValue);
    }
    uartprintf("\r\n");
}

static void serverReset(void) {
    vTaskDelay(20);
    SoftReset();
}

static void updateBaudrate(void) {
    unsigned int user_baudrate = UART_BPS;
    uartprintf("Enter new baudrate\r\n");
    uartscanf("%u", &user_baudrate);
    UARTSetDataRate(UART1, SYS_FREQ/PB_DIV, user_baudrate);
    // reset tty
    uartPutC(KEY_ESCAPE);
    uartPutC('c');
    vTaskDelay(20);
    uartprintf("Baudrate value updated to %u\r\n", user_baudrate);
}

static void serverHelp(void) {
    uartPutS((char *)helpMSG);
}

static void (*builtinfunctions[BUILTIN_COMMANDS_NUMBER])(void) = {
    &serverRead, &serverDump, &serverStream, &serverReset,
    &updateBaudrate, &serverHelp
};

void consoleInit(void) {
    // tty Config: http://www.termsys.demon.co.uk/vtansi.htm
    // clear screen
    uartPutC(KEY_ESCAPE);
    uartPutS("[2J");
    // enable scrolling
    uartPutC(KEY_ESCAPE);
    uartPutS("[r");
    // reset all attributes
    uartPutC(KEY_ESCAPE);
    uartPutS("[0m");
    // Hello World MSG
    uartprintf("freertos:~# Hello World\r\n");
}

int consoleReadCommand(void) {
    int id;
    char command[20];
    uartGetS(command);
    for (id = 0; id < BUILTIN_COMMANDS_NUMBER; id++){
        if (!strcmp(command, builtincommands[id])) {
            return id;
        }
    }
    if (!strcmp(command, "\0")) {
        return -1;
    } else {
        return -2;
    }
}

void consoleReply(int command) {
    void (*fcommand)(void);
    if(command >= 0) {
        fcommand = *builtinfunctions[command];
        fcommand();
    } else if (command != -1) {
        uartprintf("command not found!\r\n");
    }
}
