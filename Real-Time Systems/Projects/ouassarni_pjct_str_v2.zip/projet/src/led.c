/**
 * @file     led.c
 * @brief    led handling task source
 * @author   OUASSARNI Fahd
 * @date
 */

#include "led.h"

void ledConfig(void) {
    PORTSetPinsDigitalOut(IOPORT_B, BIT_10);
    // PORTSetPinsDigitalOut(IOPORT_D, BIT_1);
    // PORTSetPinsDigitalOut(IOPORT_D, BIT_2);
    return ;
}

void updateLED(void) {
    float lastTemp;
    const portTickType xLedTimeout = 50;

    if( xSemaphoreTempRead != NULL )
    {
        /* See if we can obtain the semaphore.  If the semaphore is not
        available wait 10 ticks to see if it becomes free. */
        if( xSemaphoreTake( xSemaphoreTempRead, xLedTimeout ) == pdTRUE )
        {
            /* We were able to obtain the semaphore and can now access the
            shared resource. */

            xQueueReceive(xQueueTempStream, &lastTemp, xLedTimeout);

            /* We have finished accessing the shared resource.  Release the
            semaphore. */
            xSemaphoreGive( xSemaphoreTempRead );
        }
        else
        {
            /* We could not obtain the semaphore and can therefore not access
            the shared resource safely. */
            xQueuePeek(xQueueTempStream, &lastTemp, xLedTimeout);
        }
    }

    if (lastTemp > 38.0) {
        // LED ON
        PORTWrite(IOPORT_B, BIT_10);
        // PORTWrite(IOPORT_D, BIT_1);
        // PORTWrite(IOPORT_D, BIT_2);
    } else {
        // PORTClearBits(IOPORT_D, BIT_2);
        // PORTClearBits(IOPORT_D, BIT_1);
        PORTToggleBits(IOPORT_B, BIT_10);
        // LED ON/OFF 2 Hz
    }
}
