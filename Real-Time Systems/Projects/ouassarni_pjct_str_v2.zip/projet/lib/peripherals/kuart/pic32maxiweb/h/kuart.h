/**
* @file     uart.h
* @brief    header for uart module library for pic32 mcu architecture
* @author   hugo descoubes
* @date     august 2013
*/
#ifndef   __HEADER_UART__
#define   __HEADER_UART__

/* INCLUDES DEPENDENCIES ***************/
#include <p32xxxx.h>
#include <plib.h>
#include <FreeRTOS.h>
#include <semphr.h>
#include <queue.h>

/* MACROS ***************/
#define SYS_FREQ            80000000    // bus matrix and cpu clock speed
#define PB_DIV              1		    // periphepral bus clock speed divider
#define UART_BPS            9600        // uart module baud rate
#define UART_BUFFER_SIZE    200         // circular buffer size in byte

/* SPECIAL KEYS ***************/
#define KEY_BACKSPACE       8
#define KEY_TAB             9
#define KEY_ENTER           13
#define KEY_SHIFT           16
#define KEY_CTRL            17
#define KEY_ALT             18
#define KEY_BREAK           19
#define KEY_CAPS_LOCK       20
#define KEY_ESCAPE          27
#define KEY_PAGE_UP         33
#define KEY_PAGE_DOWN       34
#define KEY_END             35
#define KEY_HOME            36
#define KEY_LEFT_ARROW      37
#define KEY_UP_ARROW        38
#define KEY_RIGHT_ARROW     39
#define KEY_DOWN_ARROW      40
#define KEY_INSERT          45
#define KEY_DELETE          46
#define KEY_LEFT_SUPER      91
#define KEY_RIGHT_SUPER     92
#define KEY_SELECT          93
#define KEY_NUMPAD0         96
#define KEY_NUMPAD1         97
#define KEY_NUMPAD2         98
#define KEY_NUMPAD3         99
#define KEY_NUMPAD4         100
#define KEY_NUMPAD5         101
#define KEY_NUMPAD6         102
#define KEY_NUMPAD7         103
#define KEY_NUMPAD8         104
#define KEY_NUMPAD9         105
#define KEY_MULTIPLY        106
#define KEY_ADD             107
#define KEY_SUBSTRACT       109
#define KEY_DECIMAL_POINT   110
#define KEY_DIVIDE          111
#define KEY_F1              112
#define KEY_F2              113
#define KEY_F3              114
#define KEY_F4              115
#define KEY_F5              116
#define KEY_F6              117
#define KEY_F7              118
#define KEY_F8              119
#define KEY_F9              120
#define KEY_F10             121
#define KEY_F11             122
#define KEY_F12             123
#define KEY_NUM_LOCK        144
#define KEY_SCROLL_LOCK     145
#define KEY_SEMICOLON       186
#define KEY_EQUAL_SIGN      187
#define KEY_COMMA           188
#define KEY_DASH            189
#define KEY_PERIOD          190
#define KEY_FORWARD_SLASH   191
#define KEY_GRAVE_ACCENT    192
#define KEY_OPEN_BRACKET    219
#define KEY_BACK_SLASH      220
#define KEY_CLOSE_BRACKET   221
#define KEY_SINGLE_QUOTE    222

/* PUBLIC DECLARATIONS ***************/
xQueueHandle xQueueUartBuffer;

xSemaphoreHandle xSemaphoreUartPutS;

/**
 * @fn void uartConfig(void)
 * @brief uart module configuration
 */
void uartConfig(void);

/**
 * @fn void interruptConfig(void)
 * @brief system interruption configuration
 */
void interruptConfig(void);

/**
 * @fn void uartPutC(char dataToSend)
 * @brief uart sending 8bits payload by polling
 * @param 8bits payload to send
 */
void uartPutC(char dataToSend);

/**
 * @fn void uartPutS(char* stringToSend)
 * @brief uart sending string by polling
 * @param pointer on string to send
 */
void uartPutS(char* stringToSend);

/**
 * @fn char uartGetC(void)
 * @brief uart receiving 8bits payload by interruption and circular buffer
 * @return received 8bits data
 */
char uartGetC(void) ;

/**
 * @fn void uartGetS(char* rxString)
 * @brief uart receiving string by interruption and circular buffer
 * @param pointer on local mcu string to save received string
 */
void uartGetS(char* stringToSave);

#endif
