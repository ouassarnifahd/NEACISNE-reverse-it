/**
* file     uart.c
* brief    uart module library for pic32 mcu architecture
* and PIC32-MAXI-WEB board from Olimex
* author   hugo descoubes
* date     september 2014
*/

/* INCLUDES DEPENDENCIES ***************/
#include <kuart.h>

int uartGetC_nbre_written_char = 0;

/**
* void __ISR(_UART_1_VECTOR, IPL2SOFT) IntUart1Handler(void)
*/
void __ISR(_UART_1_VECTOR, IPL2SOFT) IntUart1Handler(void) {

    char char_container;

    // check for data receiving
    if ( INTGetFlag(INT_SOURCE_UART_RX(UART1)) ) {

        // flush uart receiving buffer
        char_container = UARTGetDataByte(UART1);
        // Queue new char from uart
        if(xQueueSendFromISR( xQueueUartBuffer, &char_container, NULL )) {
            // clear uart receiving flag (always after uart buffer flushing)
            INTClearFlag(INT_SOURCE_UART_RX(UART1));
        }

    }
}

/**
 * void uartConfig(unsigned int baudrate)
 */
void uartConfig(void) {
    // Queue buffer initialization
    xQueueUartBuffer = xQueueCreate( UART_BUFFER_SIZE, sizeof( char ) );
    if( xQueueUartBuffer == NULL ) {
        /* Queue was not created and must not be used. */
        while(1);
    }

    // Semaphore UartPutS init
    vSemaphoreCreateBinary( xSemaphoreUartPutS );
    if( xSemaphoreUartPutS == NULL ) {
        /* There was insufficient FreeRTOS heap available for the semaphore to
        be created successfully. */
        while(1);
    }

    // standard mode without hardware handshaking
    UARTConfigure(UART1, UART_ENABLE_PINS_TX_RX_ONLY);

    // serial frame configuration
    UARTSetLineControl(UART1,  UART_DATA_SIZE_8_BITS | \
                                UART_PARITY_NONE |      \
                                UART_STOP_BITS_1);

    // data rate configuration
    UARTSetDataRate(UART1, SYS_FREQ/PB_DIV, UART_BPS);

    // enable module
    UARTEnable(UART1,  UART_ENABLE_FLAGS(UART_PERIPHERAL | UART_RX | UART_TX));

    // uart module interruption configuration
    INTClearFlag(INT_U1RX);
    INTEnable(INT_SOURCE_UART_RX(UART1), INT_ENABLED);
    INTSetVectorPriority(INT_VECTOR_UART(UART1), INT_PRIORITY_LEVEL_2);
    INTSetVectorSubPriority(INT_VECTOR_UART(UART1), INT_SUB_PRIORITY_LEVEL_0);
}

/**
 * void interruptConfig(void)
 */
void interruptConfig(void) {
  // system interruption configuration
  INTConfigureSystem(INT_SYSTEM_CONFIG_MULT_VECTOR);

  // global interruption enable
  INTEnableInterrupts();
}

/**
 * void uartPutC(char dataToSend)
 */
void uartPutC(char dataToSend) {
    // wait while transmitter is not ready
    while( !UARTTransmitterIsReady(UART1) );

    UARTSendDataByte(UART1, dataToSend);
}

/**
 * void uartPutS(char* stringToSend)
 */
void uartPutS(char* stringToSend) {
    int i;
    const portTickType uartPutS_timeout = 10;

    if( xSemaphoreUartPutS != NULL )
    {
        /* See if we can obtain the semaphore.  If the semaphore is not
        available wait uartPutS_timeout ticks to see if it becomes free. */
        if( xSemaphoreTake( xSemaphoreUartPutS, uartPutS_timeout ) == pdTRUE )
        {
            /* We were able to obtain the semaphore and can now access the
            shared resource. */

            for (i=0; stringToSend[i] != '\0'; i++)
                uartPutC( stringToSend[i] );

            /* We have finished accessing the shared resource.  Release the
            semaphore. */
            xSemaphoreGive( xSemaphoreUartPutS );
        }
        else
        {
            /* We could not obtain the semaphore and can therefore not access
            the shared resource safely. */
        }
    }

}

/**
 * char uartGetC(void)
 */
char uartGetC(void) {
    char tmp = 0;
    static char ESC_CHAR;

    // Recieve char from isr with a non blocking Queue
    const portTickType uartGetC_timeout = 20;
    xQueueReceive(xQueueUartBuffer, &tmp,  uartGetC_timeout);

    // // blink cursor
    // uartPutC(KEY_ESCAPE);
    // uartPutS("[4;5m");
    // // cursor
    // uartPutC(' ');
    // // disable blink
    // uartPutC(KEY_ESCAPE);
    // uartPutS("[0m");
    // // override cursor
    // uartPutC('\x8');

    // character echo with connected device
    switch (tmp) {
        case 0x00:
            break;
        case KEY_ENTER:
            uartGetC_nbre_written_char = 0;
            break;
        case KEY_ESCAPE:
            ESC_CHAR = 1;
            tmp = 0;
            break;
        case KEY_TAB:
            // do something useful
            // here
            tmp = 0;
            break;
        case 0x7f:
            // KEY_BACKSPACE
            if (uartGetC_nbre_written_char-- > 0) {
                uartPutC( '\x8' );
                uartPutC( ' ');
                uartPutC( '\x8' );
            }
            break;
        case '[':
            if (ESC_CHAR == 1) {
                ESC_CHAR = 2;
                tmp = 0;
                break;
            }
        case 'A':
            if (ESC_CHAR == 2) {
                // UP_ARROW
                // scroll up
                // uartPutC(KEY_ESCAPE);
                // uartPutC('M');
                tmp = 0;
                break;
            }
        case 'B':
            if (ESC_CHAR == 2) {
                // DOWN_ARROW
                // scroll down
                // uartPutC(KEY_ESCAPE);
                // uartPutC('D');
                tmp = 0;
                break;
            }
        case 'C':
            if (ESC_CHAR == 2) {
                // RIGHT_ARROW
                // do something useful
                // here
                tmp = 0;
                break;
            }
        case 'D':
            if (ESC_CHAR == 2) {
                // LEFT_ARROW
                // do something useful
                // here
                tmp = 0;
                break;
            }
        default:
            ESC_CHAR = 0;
            uartGetC_nbre_written_char++;
            uartPutC( tmp );
    }

    return tmp;
}

/**
 * void uartGetS(char* rxString)
 */
// #include "console.h"
void uartGetS(char* rxString) {
    char tmp;
    int i = 0;

    // wait for data receiving and check for ENTER key ascii code
    while ( (tmp = uartGetC()) != '\r') {
        if (tmp == 0x7f) {
            i = (i != 0) ? i - 1 : 0;
        } else if (tmp != 0 && tmp < 256) {
            // uartprintf("\r\nchar debug: '%c' == 0x%x\r\n", tmp, (unsigned int)tmp);
            rxString[i++] = tmp;
        } // else if (tmp == 0x1b) {
        //
        // }
    }
    // replace ENTER key ascii code
    rxString[i] = '\0';
    // uartprintf("\r\nstr debug: %s \r\n", rxString);
    uartPutS("\r\n");
}
